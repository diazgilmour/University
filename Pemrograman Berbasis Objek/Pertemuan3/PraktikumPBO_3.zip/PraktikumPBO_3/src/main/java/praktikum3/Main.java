/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum3;

/**
 *
 * @author khrns
 */
public class Main {
    public static void main(String[] args) { 
        Hewan kucing = new Hewan("Juli", 5);
        kucing.suara();
        kucing.info();
        kucing.berlari();
        
        Hewan anjing = new Hewan("Jack", 10);
        anjing.berlari();
    }
    
}
